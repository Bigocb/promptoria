'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, ArrowLeft, Settings, Play, X } from 'lucide-react'
import Link from 'next/link'

type Snippet = {
  id: string
  name: string
  description: string
  content: string
  version: number
  createdAt: string
}

type PromptData = {
  id: string
  name: string
  description: string
  template_body: string
  snippets: string[]
  model: string
  model_config: {
    temperature: number
    max_tokens: number
    top_p: number
  }
  versions: number
}

export default function PromptsPage() {
  // Mock data - in real app, fetch from DB
  const mockSnippets: Snippet[] = [
    {
      id: '1',
      name: 'Brand Voice',
      description: 'Our brand tone and personality',
      content: 'You are a friendly, professional assistant...',
      version: 1,
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      name: 'Format Instructions',
      description: 'Output formatting rules',
      content: 'Always respond in JSON format with clear field names.',
      version: 1,
      createdAt: new Date().toISOString(),
    },
  ]

  const [prompts, setPrompts] = useState<PromptData[]>([])
  const [isCreating, setIsCreating] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    template_body: '',
    snippets: [] as string[],
    model: 'gpt-4',
    temperature: 0.7,
    max_tokens: 2000,
    top_p: 0.9,
  })

  const handleCreatePrompt = () => {
    if (!formData.name || !formData.template_body) {
      alert('Name and template are required')
      return
    }

    if (editingId) {
      setPrompts(
        prompts.map((p) =>
          p.id === editingId
            ? {
                ...p,
                name: formData.name,
                description: formData.description,
                template_body: formData.template_body,
                snippets: formData.snippets,
                model: formData.model,
                model_config: {
                  temperature: formData.temperature,
                  max_tokens: formData.max_tokens,
                  top_p: formData.top_p,
                },
              }
            : p
        )
      )
    } else {
      const newPrompt: PromptData = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        description: formData.description,
        template_body: formData.template_body,
        snippets: formData.snippets,
        model: formData.model,
        model_config: {
          temperature: formData.temperature,
          max_tokens: formData.max_tokens,
          top_p: formData.top_p,
        },
        versions: 1,
      }
      setPrompts([...prompts, newPrompt])
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      template_body: '',
      snippets: [],
      model: 'gpt-4',
      temperature: 0.7,
      max_tokens: 2000,
      top_p: 0.9,
    })
    setIsCreating(false)
    setEditingId(null)
  }

  const toggleSnippet = (snippetId: string) => {
    setFormData({
      ...formData,
      snippets: formData.snippets.includes(snippetId)
        ? formData.snippets.filter((id) => id !== snippetId)
        : [...formData.snippets, snippetId],
    })
  }

  const getSelectedSnippets = () => {
    return mockSnippets.filter((s) => formData.snippets.includes(s.id))
  }

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Prompt Workspace</h1>
              <p className="text-slate-400">Compose and test prompts</p>
            </div>
          </div>
          <Button onClick={() => setIsCreating(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            New Prompt
          </Button>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        {isCreating && (
          <Card className="mb-8 bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">
                  {editingId ? 'Edit Prompt' : 'Create New Prompt'}
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={resetForm}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <h3 className="font-semibold text-white">Basic Information</h3>
                <div>
                  <Label htmlFor="name" className="text-white">
                    Prompt Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="e.g., Product Description Generator"
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                  />
                </div>

                <div>
                  <Label htmlFor="description" className="text-white">
                    Description (optional)
                  </Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    placeholder="What is this prompt for?"
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>

              {/* Snippet Composition */}
              <div className="space-y-4">
                <h3 className="font-semibold text-white">Compose with Snippets</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Available Snippets */}
                  <div>
                    <p className="text-sm text-slate-400 mb-3">Available Snippets</p>
                    <div className="space-y-2">
                      {mockSnippets.map((snippet) => (
                        <button
                          key={snippet.id}
                          onClick={() => toggleSnippet(snippet.id)}
                          className={`w-full text-left p-3 rounded border-2 transition-colors ${
                            formData.snippets.includes(snippet.id)
                              ? 'bg-blue-900 border-blue-500'
                              : 'bg-slate-700 border-slate-600 hover:border-slate-500'
                          }`}
                        >
                          <p className="font-medium text-white">{snippet.name}</p>
                          <p className="text-xs text-slate-400">
                            {snippet.description}
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Selected Snippets Preview */}
                  <div>
                    <p className="text-sm text-slate-400 mb-3">Selected Snippets</p>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {getSelectedSnippets().map((snippet) => (
                        <div
                          key={snippet.id}
                          className="p-3 bg-blue-900 border border-blue-500 rounded"
                        >
                          <p className="font-medium text-white text-sm">
                            {snippet.name}
                          </p>
                          <pre className="text-xs text-blue-100 mt-2 whitespace-pre-wrap break-words max-h-20 overflow-hidden">
                            {snippet.content}
                          </pre>
                        </div>
                      ))}
                      {formData.snippets.length === 0 && (
                        <p className="text-slate-500 text-sm italic">
                          No snippets selected
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Template Body */}
              <div>
                <Label htmlFor="template" className="text-white">
                  Template Body
                </Label>
                <Textarea
                  id="template"
                  value={formData.template_body}
                  onChange={(e) =>
                    setFormData({ ...formData, template_body: e.target.value })
                  }
                  placeholder="Enter your prompt template here. Use {{variable_name}} for variables."
                  className="mt-2 bg-slate-700 border-slate-600 text-white min-h-40"
                />
                <p className="text-xs text-slate-400 mt-2">
                  Use {{'{'}}{'}{'}'} syntax for variables, e.g., {{'{{'}}product_name{{'}}'}}
                </p>
              </div>

              {/* Model Configuration */}
              <div className="space-y-4 border-t border-slate-700 pt-4">
                <h3 className="font-semibold text-white">Model Configuration</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="model" className="text-white">
                      Model
                    </Label>
                    <select
                      id="model"
                      value={formData.model}
                      onChange={(e) =>
                        setFormData({ ...formData, model: e.target.value })
                      }
                      className="mt-2 w-full bg-slate-700 border border-slate-600 text-white rounded px-3 py-2"
                    >
                      <option>gpt-4</option>
                      <option>gpt-3.5-turbo</option>
                      <option>claude-3-opus</option>
                      <option>claude-3-sonnet</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="temp" className="text-white">
                      Temperature: {formData.temperature}
                    </Label>
                    <input
                      id="temp"
                      type="range"
                      min="0"
                      max="2"
                      step="0.1"
                      value={formData.temperature}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          temperature: parseFloat(e.target.value),
                        })
                      }
                      className="mt-2 w-full"
                    />
                  </div>

                  <div>
                    <Label htmlFor="tokens" className="text-white">
                      Max Tokens
                    </Label>
                    <Input
                      id="tokens"
                      type="number"
                      value={formData.max_tokens}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          max_tokens: parseInt(e.target.value),
                        })
                      }
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>

                  <div>
                    <Label htmlFor="top_p" className="text-white">
                      Top P: {formData.top_p}
                    </Label>
                    <input
                      id="top_p"
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={formData.top_p}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          top_p: parseFloat(e.target.value),
                        })
                      }
                      className="mt-2 w-full"
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 border-t border-slate-700 pt-4">
                <Button onClick={handleCreatePrompt}>
                  {editingId ? 'Update Prompt' : 'Create Prompt'}
                </Button>
                <Button variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Prompts List */}
        <div className="space-y-4">
          {prompts.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="pt-6 text-center">
                <p className="text-slate-400">
                  No prompts yet. Create one to get started!
                </p>
              </CardContent>
            </Card>
          ) : (
            prompts.map((prompt) => (
              <Card key={prompt.id} className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-white">{prompt.name}</CardTitle>
                      {prompt.description && (
                        <p className="text-sm text-slate-400 mt-1">
                          {prompt.description}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          setFormData({
                            name: prompt.name,
                            description: prompt.description,
                            template_body: prompt.template_body,
                            snippets: prompt.snippets,
                            model: prompt.model,
                            temperature: prompt.model_config.temperature,
                            max_tokens: prompt.model_config.max_tokens,
                            top_p: prompt.model_config.top_p,
                          })
                          setEditingId(prompt.id)
                          setIsCreating(true)
                        }}
                      >
                        <Settings className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Play className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-slate-400 mb-2">Snippets ({prompt.snippets.length})</p>
                      <div className="flex flex-wrap gap-2">
                        {prompt.snippets.map((snippetId) => {
                          const snippet = mockSnippets.find(
                            (s) => s.id === snippetId
                          )
                          return (
                            <span
                              key={snippetId}
                              className="bg-blue-900 text-blue-100 text-xs px-2 py-1 rounded"
                            >
                              {snippet?.name}
                            </span>
                          )
                        })}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-slate-400 mb-2">Template Preview</p>
                      <pre className="bg-slate-900 p-3 rounded text-slate-200 text-xs overflow-auto max-h-24">
                        {prompt.template_body}
                      </pre>
                    </div>

                    <div className="text-xs text-slate-400">
                      Model: {prompt.model} • v{prompt.versions} •{' '}
                      Temp: {prompt.model_config.temperature}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  )
}
