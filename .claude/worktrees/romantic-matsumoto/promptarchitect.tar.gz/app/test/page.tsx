'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Play, ArrowLeft, Copy, Check, AlertCircle, Loader } from 'lucide-react'
import Link from 'next/link'

type TestResult = {
  testRunId: string
  output: string
  inputTokens: number
  outputTokens: number
  totalTokens: number
  costUsd: number
  latencyMs: number
  status: 'success' | 'error'
  errorMessage?: string
  timestamp: string
}

export default function TestRunnerPage() {
  const [promptId, setPromptId] = useState('prompt-product-desc')
  const [versionId, setVersionId] = useState('version-product-desc-v2')
  const [variables, setVariables] = useState({
    product_name: 'Premium Wireless Headphones',
    product_category: 'Audio Equipment',
    product_price: '$199.99',
    target_audience: 'Music professionals and audiophiles',
    key_features: 'Noise cancellation, 40hr battery, premium sound quality',
    num_pain_points: '3',
  })
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<TestResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [copiedField, setCopiedField] = useState<string | null>(null)
  const [testHistory, setTestHistory] = useState<TestResult[]>([])

  const handleVariableChange = (key: string, value: string) => {
    setVariables((prev) => ({ ...prev, [key]: value }))
  }

  const handleExecute = async () => {
    setIsLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          promptVersionId: versionId,
          variables,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || data.details || 'Failed to execute prompt')
        return
      }

      const testResult: TestResult = {
        testRunId: data.testRunId,
        output: data.output,
        inputTokens: data.inputTokens,
        outputTokens: data.outputTokens,
        totalTokens: data.totalTokens,
        costUsd: data.costUsd,
        latencyMs: data.latencyMs,
        status: data.status,
        timestamp: new Date().toLocaleString(),
      }

      setResult(testResult)
      setTestHistory([testResult, ...testHistory.slice(0, 9)])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text)
    setCopiedField(fieldName)
    setTimeout(() => setCopiedField(null), 2000)
  }

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white">Test Runner</h1>
            <p className="text-slate-400">Execute and test prompts in real-time</p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Input Panel */}
          <div className="space-y-6">
            {/* Prompt Selection */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Select Prompt</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="prompt" className="text-white">
                    Prompt ID
                  </Label>
                  <Input
                    id="prompt"
                    value={promptId}
                    onChange={(e) => setPromptId(e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                    placeholder="e.g., prompt-product-desc"
                  />
                </div>

                <div>
                  <Label htmlFor="version" className="text-white">
                    Version ID
                  </Label>
                  <Input
                    id="version"
                    value={versionId}
                    onChange={(e) => setVersionId(e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white"
                    placeholder="e.g., version-product-desc-v2"
                  />
                </div>

                <p className="text-xs text-slate-400 mt-4 p-3 bg-slate-700 rounded">
                  💡 Use <code>version-product-desc-v2</code> as an example
                </p>
              </CardContent>
            </Card>

            {/* Variables Input */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Variables</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(variables).map(([key, value]) => (
                  <div key={key}>
                    <Label htmlFor={key} className="text-white text-sm">
                      {{'{{'}}
                      {key}{{'}}'}}
                    </Label>
                    <Input
                      id={key}
                      value={value}
                      onChange={(e) => handleVariableChange(key, e.target.value)}
                      className="mt-1 bg-slate-700 border-slate-600 text-white text-sm"
                      placeholder={`Enter ${key}`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Execute Button */}
            <Button
              onClick={handleExecute}
              disabled={isLoading}
              className="w-full gap-2 h-12 text-base"
              size="lg"
            >
              {isLoading ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Executing...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Execute Prompt
                </>
              )}
            </Button>
          </div>

          {/* Right: Results Panel */}
          <div className="space-y-6">
            {/* Error Display */}
            {error && (
              <Card className="bg-red-900/20 border-red-700">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                    <CardTitle className="text-red-100">Error</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="text-red-100 text-sm">{error}</CardContent>
              </Card>
            )}

            {/* Success Result */}
            {result && result.status === 'success' && (
              <>
                {/* Output */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">Output</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(result.output, 'output')}
                      >
                        {copiedField === 'output' ? (
                          <>
                            <Check className="w-4 h-4 text-green-500" />
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-slate-900 p-4 rounded text-slate-200 text-sm max-h-64 overflow-y-auto whitespace-pre-wrap">
                      {result.output}
                    </div>
                  </CardContent>
                </Card>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-slate-800 border-slate-700">
                    <CardContent className="pt-6">
                      <p className="text-slate-400 text-xs mb-1">Input Tokens</p>
                      <p className="text-2xl font-bold text-white">
                        {result.inputTokens}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardContent className="pt-6">
                      <p className="text-slate-400 text-xs mb-1">Output Tokens</p>
                      <p className="text-2xl font-bold text-white">
                        {result.outputTokens}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardContent className="pt-6">
                      <p className="text-slate-400 text-xs mb-1">Cost</p>
                      <p className="text-2xl font-bold text-green-400">
                        ${result.costUsd.toFixed(4)}
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-800 border-slate-700">
                    <CardContent className="pt-6">
                      <p className="text-slate-400 text-xs mb-1">Latency</p>
                      <p className="text-2xl font-bold text-blue-400">
                        {result.latencyMs}ms
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Detailed Metrics */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Details</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-slate-300 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Test Run ID:</span>
                      <code className="font-mono text-xs">{result.testRunId}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Tokens:</span>
                      <span>{result.totalTokens}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Timestamp:</span>
                      <span>{result.timestamp}</span>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {/* Test History */}
            {testHistory.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm">Recent Tests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {testHistory.map((test) => (
                      <div
                        key={test.testRunId}
                        className="p-3 bg-slate-700 rounded hover:bg-slate-600 cursor-pointer transition-colors text-sm"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-slate-200">{test.timestamp}</span>
                          <span
                            className={`text-xs font-bold ${
                              test.status === 'success'
                                ? 'text-green-400'
                                : 'text-red-400'
                            }`}
                          >
                            {test.status.toUpperCase()}
                          </span>
                        </div>
                        {test.status === 'success' && (
                          <div className="text-xs text-slate-400 mt-2">
                            💰 ${test.costUsd.toFixed(4)} • ⚡ {test.latencyMs}ms •
                            📊 {test.totalTokens} tokens
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
