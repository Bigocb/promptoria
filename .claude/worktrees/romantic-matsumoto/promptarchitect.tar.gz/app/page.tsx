'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { BookOpen, Zap, History, Play } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold text-white mb-2">PromptArchitect</h1>
          <p className="text-slate-300">Modular, versioned prompt management</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {/* Snippet Library Card */}
          <Link href="/snippets" className="block">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <BookOpen className="w-8 h-8 text-blue-500 mb-2" />
                <CardTitle>Snippet Library</CardTitle>
                <CardDescription>Manage reusable text blocks</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Create and organize reusable snippets that can be composed into prompts. Perfect for brand voice, system instructions, and common patterns.
                </p>
              </CardContent>
            </Card>
          </Link>

          {/* Prompt Workspace Card */}
          <Link href="/prompts" className="block">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <Zap className="w-8 h-8 text-amber-500 mb-2" />
                <CardTitle>Prompt Workspace</CardTitle>
                <CardDescription>Build and compose prompts</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Create prompts by composing snippets and templates. Add variables, configure LLM settings, and manage multiple versions.
                </p>
              </CardContent>
            </Card>
          </Link>

          {/* Version History Card */}
          <Link href="/history" className="block">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <History className="w-8 h-8 text-green-500 mb-2" />
                <CardTitle>Version History</CardTitle>
                <CardDescription>Compare and manage versions</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Track changes across prompt versions, compare differences, and understand the evolution of your prompts over time.
                </p>
              </CardContent>
            </Card>
          </Link>

          {/* Test Runner Card */}
          <Link href="/test" className="block">
            <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <Play className="w-8 h-8 text-purple-500 mb-2" />
                <CardTitle>Test Runner</CardTitle>
                <CardDescription>Execute and test prompts</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Run prompts with real LLM API calls, see outputs, track token usage, and monitor costs. All results are logged for analysis.
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Getting Started Section */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Getting Started</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-semibold text-white">1. Create a Snippet</h3>
              <p className="text-sm text-slate-300">
                Go to <Link href="/snippets" className="text-blue-400 hover:underline">Snippet Library</Link> and create your first reusable text block, like a "Brand Voice" snippet.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-white">2. Build a Prompt</h3>
              <p className="text-sm text-slate-300">
                Navigate to <Link href="/prompts" className="text-blue-400 hover:underline">Prompt Workspace</Link> to create a new prompt and compose it with your snippets.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-white">3. Test & Monitor</h3>
              <p className="text-sm text-slate-300">
                Go to <Link href="/test" className="text-blue-400 hover:underline">Test Runner</Link> to execute prompts with real LLM APIs, see outputs, track token usage, and monitor costs. All test results are automatically logged.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
